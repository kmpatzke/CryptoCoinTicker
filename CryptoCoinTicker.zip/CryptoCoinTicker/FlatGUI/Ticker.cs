﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlatGUI
{
    class Ticker
    {

        // Abbilden der Wertde, die die API zurückgibt ---------------------------------------------
        private string mid;
        private string bid;
        private string ask;
        private string last_price;
        private string low;
        private string high;
        private string volume;
        private string timestamp;

        public string Mid { get => mid; set => mid = value; }
        public string Bid { get => bid; set => bid = value; }
        public string Ask { get => ask; set => ask = value; }
        public string Last_price { get => last_price; set => last_price = value; }
        public string Low { get => low; set => low = value; }
        public string High { get => high; set => high = value; }
        public string Volume { get => volume; set => volume = value; }
        public string Timestamp { get => timestamp; set => timestamp = value; }
    }
}
