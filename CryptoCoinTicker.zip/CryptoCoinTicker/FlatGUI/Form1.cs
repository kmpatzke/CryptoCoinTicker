﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;

namespace FlatGUI
{
    public partial class CryptoCoinTicker : Form
    {
        

        #region Make Window Dragable Variables----------------------------
        private bool mouseDown;
        private Point lastPoint;
        private Ticker ticker;
        #endregion--------------------------------------------------------

        #region RestClient ----------------------------------------------
        private RestClient client = new RestClient();
        #endregion-------------------------------------------------------

        #region STATS ----------------------------------------------------------  
        private string currency;
        private string price;
        private string low;
        private string high;
        #endregion --------------------------------------------------------------

        #region PAIR/ METHOD--------------------------------------------
        private string pair;
        private string method;
        #endregion------------------------------------------------------

        public CryptoCoinTicker()
        {
            InitializeComponent();
            tableLayoutPanel1.Visible = false;
            labelFetching.Visible = false; // Show that data is being fetched right now
            
        }


        #region WindowFuncions ----------------------------------------------
        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        #endregion--------------------------------------------------------------

        #region COIN_BUTTONS-----------------------------------------------------------  
        void ButtonClick(object sender, EventArgs e)
        {
            PictureBox temp = (PictureBox)sender;
            this.pair = temp.Name;
            this.method = "get";
            getStats(pair, method);
            drawStats();
            tableLayoutPanel1.Visible = true;
            timer1.Start();
        }

        #endregion----------------------------------------------------------------------


        #region FUNKTIONEN--------------------------------------------------------------

        private async void getStats(string pair, string method) // Asynchronous to make the Program usable even if data is not fetched yet
        {
            labelFetching.Visible = true; // Fetch label shows

            string clientResponse = await Task.Run(()=>client.makeRequest(pair, method));

            

            JavaScriptSerializer serializer = new JavaScriptSerializer();

            try
            {
                ticker = (Ticker)serializer.Deserialize(clientResponse, typeof(Ticker));
            }
            catch(Exception ex)
            {
                throw new ApplicationException("error: " + ex.Message);
            }
           

            
            this.price = ticker.Last_price;
            this.high = ticker.High;
            this.low = ticker.Low;

            switch (this.pair)
            {
                case "BTCUSD": this.currency = "Bitcoin";
                    break;
                case "XRPUSD": this.currency = "Ripple";
                    break;
                case "IOTUSD": this.currency = "IOTA";
                    break;
                case "ETHUSD": this.currency = "Ethereum";
                    break;
            }

            drawStats();
            labelFetching.Visible = false; // Fetch 
        }

        

        void drawStats()
        {
            labelCurrency.Text = this.currency;
            labelPrice.Text = this.price;
            labelHigh.Text = this.high;
            labelLow.Text = this.low;
        }
        #endregion----------------------------------------------------------------------

        #region make Window dragable
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastPoint = e.Location;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point((this.Location.X - lastPoint.X) + e.X, (this.Location.Y - lastPoint.Y) + e.Y);
                this.Update();
            }
        }
        #endregion

        #region TIMER------------------------------------------------------------------
        private void timer1_Tick(object sender, EventArgs e)
        {
            getStats(pair, method);
            drawStats();
        }
        #endregion---------------------------------------------------------------------
    }
}
