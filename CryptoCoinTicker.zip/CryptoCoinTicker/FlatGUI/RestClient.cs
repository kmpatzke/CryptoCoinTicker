﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Net;
using System.IO;

namespace FlatGUI
{
    
    class RestClient
    {
       
        private string url;
        private string endPoint;

        public RestClient()
        {
            this.url = "https://api.bitfinex.com/v1/pubticker/"; // Klar... Die BasisURL der API
            
        }
        
        //Server wird um Antwort gebeten für ein spezielles Währungspaar (gleichzeitig endpoint)|| Für dieses Programmbeispiel wird zwar immer die Get-Methode verwendet, aber eine andere ist natürlich denkbar
        //In diesem fall könnten auch Enumerations benutzt werden, um eine bessere Übersichtlichkeit zu wahren

        public string makeRequest(string pair, string method)
        {
            string response = String.Empty;
            this.endPoint = pair;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url + endPoint);
            request.Method = method;

            // KeyWord using wird hier benutzt, da die Objecte folgender Klassen nur einmalig gebraucht werden--------------------------------------
            using(HttpWebResponse serverResponse = (HttpWebResponse)request.GetResponse())
            {
                if(serverResponse.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApplicationException("error" + serverResponse.StatusCode.ToString());
                }

                using (Stream responseStream = serverResponse.GetResponseStream())
                {
                    if(responseStream != null)
                    {
                        using(StreamReader reader = new StreamReader(responseStream))
                        {
                            response = reader.ReadToEnd();
                        }
                    }
                }

            }

            return response;
        }


        //Properties
        public string EndPoint { get => endPoint; set => endPoint = value; }
    }
}
