﻿namespace FlatGUI
{
    partial class CryptoCoinTicker
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CryptoCoinTicker));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BTCUSD = new System.Windows.Forms.PictureBox();
            this.XRPUSD = new System.Windows.Forms.PictureBox();
            this.ETHUSD = new System.Windows.Forms.PictureBox();
            this.IOTUSD = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.labelLow = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.labelHigh = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelCurrency = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelFetching = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.BTCUSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.XRPUSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ETHUSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IOTUSD)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "-";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(34, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "x";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Default;
            this.label3.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(376, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(226, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Crypto Coin Ticker";
            // 
            // BTCUSD
            // 
            this.BTCUSD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTCUSD.Image = global::FlatGUI.Properties.Resources.BitCoinVector;
            this.BTCUSD.InitialImage = ((System.Drawing.Image)(resources.GetObject("BTCUSD.InitialImage")));
            this.BTCUSD.Location = new System.Drawing.Point(133, 136);
            this.BTCUSD.Name = "BTCUSD";
            this.BTCUSD.Size = new System.Drawing.Size(120, 120);
            this.BTCUSD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BTCUSD.TabIndex = 3;
            this.BTCUSD.TabStop = false;
            this.BTCUSD.Click += new System.EventHandler(this.ButtonClick);
            // 
            // XRPUSD
            // 
            this.XRPUSD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.XRPUSD.Image = ((System.Drawing.Image)(resources.GetObject("XRPUSD.Image")));
            this.XRPUSD.InitialImage = ((System.Drawing.Image)(resources.GetObject("XRPUSD.InitialImage")));
            this.XRPUSD.Location = new System.Drawing.Point(335, 136);
            this.XRPUSD.Name = "XRPUSD";
            this.XRPUSD.Size = new System.Drawing.Size(120, 120);
            this.XRPUSD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.XRPUSD.TabIndex = 4;
            this.XRPUSD.TabStop = false;
            this.XRPUSD.Click += new System.EventHandler(this.ButtonClick);
            // 
            // ETHUSD
            // 
            this.ETHUSD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ETHUSD.Image = ((System.Drawing.Image)(resources.GetObject("ETHUSD.Image")));
            this.ETHUSD.InitialImage = ((System.Drawing.Image)(resources.GetObject("ETHUSD.InitialImage")));
            this.ETHUSD.Location = new System.Drawing.Point(733, 136);
            this.ETHUSD.Name = "ETHUSD";
            this.ETHUSD.Size = new System.Drawing.Size(120, 120);
            this.ETHUSD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ETHUSD.TabIndex = 6;
            this.ETHUSD.TabStop = false;
            this.ETHUSD.Click += new System.EventHandler(this.ButtonClick);
            // 
            // IOTUSD
            // 
            this.IOTUSD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IOTUSD.Image = ((System.Drawing.Image)(resources.GetObject("IOTUSD.Image")));
            this.IOTUSD.InitialImage = ((System.Drawing.Image)(resources.GetObject("IOTUSD.InitialImage")));
            this.IOTUSD.Location = new System.Drawing.Point(531, 136);
            this.IOTUSD.Name = "IOTUSD";
            this.IOTUSD.Size = new System.Drawing.Size(120, 120);
            this.IOTUSD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.IOTUSD.TabIndex = 5;
            this.IOTUSD.TabStop = false;
            this.IOTUSD.Click += new System.EventHandler(this.ButtonClick);
            // 
            // timer1
            // 
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.77778F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.75F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.Controls.Add(this.label15, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelLow, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label12, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelHigh, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label9, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelPrice, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelCurrency, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(133, 333);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(720, 100);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Cursor = System.Windows.Forms.Cursors.Default;
            this.label15.Dock = System.Windows.Forms.DockStyle.Right;
            this.label15.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label15.Location = new System.Drawing.Point(563, 75);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(154, 25);
            this.label15.TabIndex = 14;
            this.label15.Text = ".......... $";
            // 
            // labelLow
            // 
            this.labelLow.AutoSize = true;
            this.labelLow.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelLow.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelLow.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLow.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelLow.Location = new System.Drawing.Point(203, 75);
            this.labelLow.Name = "labelLow";
            this.labelLow.Size = new System.Drawing.Size(22, 25);
            this.labelLow.TabIndex = 13;
            this.labelLow.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Cursor = System.Windows.Forms.Cursors.Default;
            this.label13.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label13.Location = new System.Drawing.Point(3, 75);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 24);
            this.label13.TabIndex = 12;
            this.label13.Text = "Low:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Cursor = System.Windows.Forms.Cursors.Default;
            this.label12.Dock = System.Windows.Forms.DockStyle.Right;
            this.label12.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(563, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(154, 25);
            this.label12.TabIndex = 11;
            this.label12.Text = ".......... $";
            // 
            // labelHigh
            // 
            this.labelHigh.AutoSize = true;
            this.labelHigh.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelHigh.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelHigh.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHigh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelHigh.Location = new System.Drawing.Point(203, 50);
            this.labelHigh.Name = "labelHigh";
            this.labelHigh.Size = new System.Drawing.Size(22, 25);
            this.labelHigh.TabIndex = 10;
            this.labelHigh.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Cursor = System.Windows.Forms.Cursors.Default;
            this.label10.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(3, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "High:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Cursor = System.Windows.Forms.Cursors.Default;
            this.label9.Dock = System.Windows.Forms.DockStyle.Right;
            this.label9.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(563, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(154, 25);
            this.label9.TabIndex = 8;
            this.label9.Text = ".......... $";
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelPrice.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelPrice.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPrice.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelPrice.Location = new System.Drawing.Point(203, 25);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(22, 25);
            this.labelPrice.TabIndex = 7;
            this.labelPrice.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Cursor = System.Windows.Forms.Cursors.Default;
            this.label7.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(3, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Price:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Cursor = System.Windows.Forms.Cursors.Default;
            this.label6.Dock = System.Windows.Forms.DockStyle.Right;
            this.label6.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(563, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = ".......... $";
            // 
            // labelCurrency
            // 
            this.labelCurrency.AutoSize = true;
            this.labelCurrency.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelCurrency.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelCurrency.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCurrency.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelCurrency.Location = new System.Drawing.Point(203, 0);
            this.labelCurrency.Name = "labelCurrency";
            this.labelCurrency.Size = new System.Drawing.Size(22, 25);
            this.labelCurrency.TabIndex = 4;
            this.labelCurrency.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Cursor = System.Windows.Forms.Cursors.Default;
            this.label4.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Currency:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(912, 29);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(92, 54);
            this.panel1.TabIndex = 8;
            // 
            // labelFetching
            // 
            this.labelFetching.AutoSize = true;
            this.labelFetching.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelFetching.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFetching.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelFetching.Location = new System.Drawing.Point(377, 288);
            this.labelFetching.Name = "labelFetching";
            this.labelFetching.Size = new System.Drawing.Size(126, 19);
            this.labelFetching.TabIndex = 9;
            this.labelFetching.Text = "Fetching.....";
            // 
            // CryptoCoinTicker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(1057, 625);
            this.Controls.Add(this.labelFetching);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.ETHUSD);
            this.Controls.Add(this.IOTUSD);
            this.Controls.Add(this.XRPUSD);
            this.Controls.Add(this.BTCUSD);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CryptoCoinTicker";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.BTCUSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.XRPUSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ETHUSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IOTUSD)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox BTCUSD;
        private System.Windows.Forms.PictureBox XRPUSD;
        private System.Windows.Forms.PictureBox ETHUSD;
        private System.Windows.Forms.PictureBox IOTUSD;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label labelLow;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label labelHigh;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelCurrency;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelFetching;
    }
}

